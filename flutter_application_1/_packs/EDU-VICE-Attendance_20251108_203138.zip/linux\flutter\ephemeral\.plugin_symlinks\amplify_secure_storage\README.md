# amplify_secure_storage

A package for storing secrets, intended for use in Amplify libraries.

## Pigeon

This package uses [`pigeon`](https://pub.dev/packages/pigeon) for communication with the host platform. To regenerate the models, run `make pigeons`

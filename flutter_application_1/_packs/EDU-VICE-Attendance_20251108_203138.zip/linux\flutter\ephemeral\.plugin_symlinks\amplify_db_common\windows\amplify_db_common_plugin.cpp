// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

#include "include/amplify_db_common/amplify_db_common_plugin.h"

void AmplifyDbCommonPluginRegisterWithRegistrar(
    FlutterDesktopPluginRegistrarRef registrar) {
}

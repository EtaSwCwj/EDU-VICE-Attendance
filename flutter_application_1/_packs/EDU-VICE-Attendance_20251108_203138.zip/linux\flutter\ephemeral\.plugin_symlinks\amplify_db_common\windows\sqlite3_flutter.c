// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

#define SQLITE_API __declspec(dllexport)
#include "sqlite3.c"

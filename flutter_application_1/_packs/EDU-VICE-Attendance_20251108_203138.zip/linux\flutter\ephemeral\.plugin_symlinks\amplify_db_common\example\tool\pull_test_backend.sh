#!/bin/bash

# No-op since amplify_db_common does not require a backend for integration tests

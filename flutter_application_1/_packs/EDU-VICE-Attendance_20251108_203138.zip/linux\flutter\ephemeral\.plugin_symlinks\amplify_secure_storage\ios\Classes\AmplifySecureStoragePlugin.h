#import <Flutter/Flutter.h>

@interface AmplifySecureStoragePlugin : NSObject<FlutterPlugin>
@end

// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

#ifndef amplify_secure_storage_h
#define amplify_secure_storage_h

#import "AmplifySecureStoragePlugin.h"

#endif /* amplify_secure_storage_h */

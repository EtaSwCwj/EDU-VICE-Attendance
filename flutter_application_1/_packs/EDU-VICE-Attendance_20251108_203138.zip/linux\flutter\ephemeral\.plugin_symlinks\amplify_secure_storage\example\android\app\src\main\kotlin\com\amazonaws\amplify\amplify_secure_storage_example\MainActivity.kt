/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

package com.amazonaws.amplify.amplify_secure_storage_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

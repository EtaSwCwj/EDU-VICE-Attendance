# BIG_030: 웹 서버 재테스트

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

웹 서버 다시 실행:

```bash
call C:\gitproject\EDU-VICE-Attendance\scripts\start_web.bat
```

DataStore 이슈 해결됐으니 이번엔 앱 화면 나와야 함.

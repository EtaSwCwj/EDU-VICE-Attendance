# BIG_026: 웹 서버 실행

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

새 터미널 창에서 Flutter 웹 서버 실행:

```bash
start cmd /k "cd /d C:\gitproject\EDU-VICE-Attendance\flutter_application_1 && flutter run -d chrome --web-port=8080"
```

위 명령어 실행해서 새 창에서 서버 띄워.

성공 조건: 새 CMD 창이 열리고 Flutter 빌드 시작됨

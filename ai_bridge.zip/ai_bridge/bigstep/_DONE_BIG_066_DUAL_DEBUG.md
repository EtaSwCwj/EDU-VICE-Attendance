# BIG_066: 듀얼 디버깅 (폰 + Chrome)

> **작성자**: 윈선임 (Desktop Opus)
> **작성일**: 2025-12-22

---

## 📋 작업

듀얼 디버깅 - flutter run 폰 + chrome 동시 실행

# BIG_062: 듀얼 디버깅 (폰 + Chrome)

> **작성자**: 윈선임 (Desktop Opus)
> **작성일**: 2025-12-22

---

## 📋 작업

듀얼 디버깅 실행 - flutter run 폰 + chrome 동시

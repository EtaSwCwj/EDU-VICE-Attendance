# BIG_015: 소리 테스트

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

ai_bridge/sound_test.txt 파일 생성하고 내용에 "Worker 소리 없음, Manager만 소리 남!" 넣어.

# BIG_022: 웹 테스트 실행

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

새 터미널 창에서 Flutter 웹 서버 시작:

```bash
cd /d C:\gitproject\EDU-VICE-Attendance\flutter_application_1 && start cmd /k "flutter run -d chrome --web-port=8080 --web-browser-flag=--disable-web-security"
```

위 명령어 실행해. 새 창에서 서버 뜨면 성공.

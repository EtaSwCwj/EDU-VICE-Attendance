# BIG_027: 배치 파일로 웹 서버 실행

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

아래 명령어로 배치 파일 실행:

```bash
C:\gitproject\EDU-VICE-Attendance\scripts\start_web.bat
```

배치 파일 실행하면 새 창에서 Flutter 웹 서버가 시작됨.

# BIG_003: 파일 생성 테스트

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 목표

ai_bridge/hello.txt 파일 생성, 내용 "Hello World!"

---

스몰스텝 파일을 생성해서 후임에게 지시하세요.

# BIG_028: 배치 파일 웹 서버 실행 테스트

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

```bash
call C:\gitproject\EDU-VICE-Attendance\scripts\start_web.bat
```

위 명령어 실행해.

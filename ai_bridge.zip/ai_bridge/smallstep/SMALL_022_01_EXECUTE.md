# SMALL_022_01_EXECUTE.md

> **빅스텝**: BIG_022_RUN_WEB.md

---

## 📋 작업 내용

# BIG_022: 웹 테스트 실행

> **작성자**: Desktop Opus
> **작성일**: 2025-12-21

---

## 📋 작업

1. `scripts\run_web_test.bat` 실행해서 웹 서버 시작
2. 실행되면 CP한테 알려줘:
   - "웹 서버 시작됨. localhost:8080 접속 가능"
   - "시크릿 모드(Ctrl+Shift+N)로 두 번째 창 열어서 다른 계정 테스트 가능"


---

**결과는 `C:\gitproject\EDU-VICE-Attendance\ai_bridge\result\small_022_01_result.md`에 저장할 것.**
